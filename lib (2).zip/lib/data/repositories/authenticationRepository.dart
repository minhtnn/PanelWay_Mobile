import 'package:panelway_mobile/core/constants/api_endpoints.dart';
import 'package:panelway_mobile/core/exceptions/api_exception.dart';
import 'package:panelway_mobile/data/models/account.dart';
import 'package:panelway_mobile/data/payloads/requests/login_request.dart';
import 'package:panelway_mobile/data/services/api_service.dart';

class AuthenticationRepository {
  final ApiService _apiService;

  AuthenticationRepository(this._apiService);

  Future<Account?> login(String email, String password, String role) async {
    try {
      var data = LoginRequest(email: email, password: password, role: role);
      var response = await _apiService.post(ApiEndpoints.login, data.toJson());
      if (response == null || response.data == null) {
        throw ApiException('Login failed: No response from server');
      }
      final responseData = response.data as Map<String, dynamic>;
      var account = Account.fromJson(responseData);
      return account;
    } on ApiException catch (e) {
      throw ApiException(e.message, statusCode: e.statusCode);
    } catch (e) {
      throw ApiException('Unexpected error during login');
    }
  }
}
